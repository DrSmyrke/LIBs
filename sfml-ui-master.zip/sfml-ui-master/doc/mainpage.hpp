////////////////////////////////////////////////////////////
/// \mainpage
///
/// \section welcome Welcome
/// Welcome to the official SFML-UI documentation. Here you will find a detailed
/// view of all the SFML-UI <a href="./annotated.php">classes</a> and functions.
////////////////////////////////////////////////////////////
